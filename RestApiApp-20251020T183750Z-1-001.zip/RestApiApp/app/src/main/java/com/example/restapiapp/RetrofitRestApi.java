package com.example.restapiapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RetrofitRestApi {

    @GET("greeting")
    Call<Greeting> getGreeting(@Query("name") String name);
}
