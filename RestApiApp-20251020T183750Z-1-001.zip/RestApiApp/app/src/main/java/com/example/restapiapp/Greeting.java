package com.example.restapiapp;

public class Greeting {
    private long id;
    private String content;


    public long getId() {
        return id;
    }

    public String getContent() {
        return content;
    }
}
