package com.example.restapiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    public static final String BASE_URL = "https://itec-6450-355213.appspot.com/";
    private TextView textViewResult;
    private RetrofitRestApi api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.txtViewResult);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        api = retrofit.create(RetrofitRestApi.class);


    }

    public void getMessage(View view){

        EditText editText = findViewById(R.id.editTextName);

        Call<Greeting> call = api.getGreeting(editText.getText().toString());

        call.enqueue(new Callback<Greeting>() {
            @Override
            public void onResponse(Call<Greeting> call, Response<Greeting> response) {
                if(!response.isSuccessful()){
                    textViewResult.setText("Code: " + response.code());
                    return;
                }

                Greeting greeting = response.body();
                textViewResult.setText(greeting.getContent());
            }

            @Override
            public void onFailure(Call<Greeting> call, Throwable t) {
                textViewResult.setText((t.getMessage()));
            }
        });
    }
}