package edu.mga.userapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.jakewharton.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

    private List<User> userList;
    private Context context;

    public CustomAdapter(Context context,List<User> userList){
        this.context = context;
        this.userList = userList;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public final View mView;

        TextView txtId;
        TextView txtCountry;
        TextView txtName;

        CustomViewHolder(View itemView) {
            super(itemView);
            mView = itemView;

            txtId = mView.findViewById(R.id.txtId);
            txtCountry = mView.findViewById(R.id.txtCountry);
            txtName = mView.findViewById(R.id.txtName);
        }
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.custom_row, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.txtId.setText(userList.get(position).getId().toString());
        holder.txtCountry.setText(userList.get(position).getCountry());
        holder.txtName.setText(userList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }
}
