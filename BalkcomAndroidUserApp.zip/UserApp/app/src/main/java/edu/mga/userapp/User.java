package edu.mga.userapp;

import com.google.gson.annotations.SerializedName;

public class User {

    @SerializedName("id")
    private Long id;
    @SerializedName("country")
    private String country;
    @SerializedName("name")
    private String name;

    public User(){
    }

    public User(String country, String name){
        this.country = country;
        this.name = name;
    }

    public User(Long id, String country, String name){
        this.id = id;
        this.country = country;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public String getCountry() {
        return country;
    }

    public String getName() {
        return name;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", country='" + country + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
