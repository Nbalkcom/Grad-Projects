package com.example.addtwonumbers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView result;
    Button Answer;
    EditText num1,num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = (TextView) findViewById(R.id.numberResult);
        Answer = (Button) findViewById(R.id.taskButton);
        num1 = (EditText) findViewById(R.id.firstNumber);
        num2 = (EditText) findViewById(R.id.secondNumber);

        Answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n1 = num1.getText().toString();
                String n2 = num2.getText().toString();
                int number1 = Integer.parseInt(n1);
                int number2 = Integer.parseInt(n2);

                int res = number1 + number2;
                result.setText(Integer.toString(res));

                clear();
            }
        });
    }
    public void clear(){
        num1.setText("");
        num2.setText("");
    }
}