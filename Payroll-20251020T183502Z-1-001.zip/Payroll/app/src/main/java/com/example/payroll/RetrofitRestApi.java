package com.example.payroll;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitRestApi {

    @GET("employees")
    Call<List<Employee>> getEmployees();

    @POST("employees")
    Call<Employee> createEmployee(@Body Employee employee);
}
