package com.example.payroll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EdgeEffect;
import android.widget.EditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NewEmployeeActivity extends AppCompatActivity {
    private EditText editName;
    private EditText editRole;
    private RetrofitRestApi retrofitRestApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_employee);

        editName = findViewById(R.id.editName);
        editRole = findViewById(R.id.editRole);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://lofty-shine-355920.ue.r.appspot.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        retrofitRestApi = retrofit.create(RetrofitRestApi.class);
    }

    public void createNewEmployee(View view){
        createEmployee();
    }

    private void createEmployee(){
        Employee employee = new Employee();
        employee.setName(editName.getText().toString());
        employee.setRole(editRole.getText().toString());

        Call<Employee> call = retrofitRestApi.createEmployee(employee);

        call.enqueue(new Callback<Employee>() {
            @Override
            public void onResponse(Call<Employee> call, Response<Employee> response) {
                if(!response.isSuccessful()){
                    Log.e("Error: ",response.toString());
                    return;
                }
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }

            @Override
            public void onFailure(Call<Employee> call, Throwable t) {
                Log.e("Error: ",t.getMessage());
            }
        });
    }
}